A Pen created at CodePen.io. You can find this one at http://codepen.io/nodws/pen/ZpZjpQ.

 Post preview with Css animations and svg icon sprite 